import torch
import torch.nn as nn
from torch.nn import functional as F
import re
import os
from flask import Flask, render_template
from flask_socketio import SocketIO

# ==========================================
# 1. SETUP & MODEL
# ==========================================
torch.set_num_threads(1)
block_size = 64
device = 'cpu'

with open('my_personal_data.txt', 'r', encoding='utf-8') as f:
    text = f.read().lower()

words = re.findall(r'\w+|[^\w\s]', text)
vocab = sorted(list(set(words)))
vocab_size = len(vocab)
stoi = { w:i for i,w in enumerate(vocab) }
itos = { i:w for i,w in enumerate(vocab) }
encode = lambda s: [stoi.get(w, 0) for w in re.findall(r'\w+|[^\w\s]', s.lower())]
decode = lambda l: ' '.join([itos[i] for i in l])

class MerelModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.token_embedding = nn.Embedding(vocab_size, 64)
        self.position_embedding = nn.Embedding(block_size, 64)
        self.lm_head = nn.Linear(64, vocab_size)

    def forward(self, idx):
        B, T = idx.shape
        tok_emb = self.token_embedding(idx)
        pos_emb = self.position_embedding(torch.arange(T, device=device))
        x = tok_emb + pos_emb
        logits = self.lm_head(x)
        return logits, x

    def generate(self, idx, max_new_tokens):
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -block_size:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :]
            probs = F.softmax(logits, dim=-1)
            idx_next = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, idx_next), dim=1)
        return idx

# --- FIX: Actually define the model! ---
model = MerelModel().to(device)
if os.path.exists('merel_words.pth'):
    model.load_state_dict(torch.load('merel_words.pth', map_location=device))
    print("Brain loaded!")
model.eval()

# ==========================================
# 2. FLASK SERVER
# ==========================================
app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('user_message')
def handle_message(data):
    user_input = data['text']

    # The System Prompt: Injecting her identity and personality
    system_prompt = "merelprrrr: ik ben merel. ik ben een trans vrouw. ik ben trots. "

    prompt = f"{system_prompt}dennis: {user_input} \nmerelprrrr: "
    context = torch.tensor([encode(prompt)], dtype=torch.long, device=device)

    with torch.no_grad():
        generated = model.generate(context, max_new_tokens=15)[0].tolist()
        _, hidden_state = model(context)

    response = decode(generated)

    # 1. Remove the system prompt from her generated output
    response = response.replace(system_prompt, "")

    # 2. Grab everything after her name
    her_response = response.split("merelprrrr:")[-1].strip()

    # 3. Clean up any leftover tags
    her_response = her_response.replace("dennis", "").replace(":", "").strip()

    # Visual data (Just the neuron activations, no attention)
    brain_activity = hidden_state[0, -1, :].tolist()
    attention_matrix = [] # Empty matrix since we don't have attention heads in this version

    socketio.emit('merel_response', {
        'text': her_response,
        'brain_activity': brain_activity,
        'attention': attention_matrix
    })

if __name__ == '__main__':
    socketio.run(app, host='127.0.0.1', port=8000, debug=True, allow_unsafe_werkzeug=True, use_reloader=False)
