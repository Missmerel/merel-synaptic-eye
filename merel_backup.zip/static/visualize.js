const socket = io();
const chatHistory = document.getElementById('chat-history');
const userInput = document.getElementById('user-input');

// ==========================================
// PIXIJS SETUP
// ==========================================
const app = new PIXI.Application({
    resizeTo: document.getElementById('brain-container'),
    backgroundColor: 0x050505,
    antialias: true
});
document.getElementById('brain-container').appendChild(app.view);

// 1. Create a container for the brain
const brainContainer = new PIXI.Container();
app.stage.addChild(brainContainer);

// 2. Add a Glow Filter (if available, otherwise it degrades gracefully)
const glowFilter = new PIXI.filters.BlurFilter();
glowFilter.blur = 2;
// brainContainer.filters = [glowFilter]; // Uncomment if you want soft blur

// 3. Create Graphics layers
const connectionGraphics = new PIXI.Graphics();
const neuronGraphics = new PIXI.Graphics();
const particleGraphics = new PIXI.Graphics();
const trailGraphics = new PIXI.Graphics(); // For the fading trails

brainContainer.addChild(trailGraphics);
brainContainer.addChild(connectionGraphics);
brainContainer.addChild(neuronGraphics);
brainContainer.addChild(particleGraphics);

let particles = [];
let currentActivations = new Array(128).fill(0);
let nodeHistory = []; // To store previous positions for trails

// ==========================================
// CHAT LOGIC
// ==========================================
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && userInput.value.trim() !== '') {
        const text = userInput.value;
        userInput.value = '';

        addMessage('You', text, 'user');
        socket.emit('user_message', { text: text });
    }
});

function addMessage(sender, text, className) {
    const div = document.createElement('div');
    div.className = `msg ${className}`;
    div.innerHTML = `<strong>${sender}:</strong> ${text}`;
    chatHistory.appendChild(div);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// ==========================================
// RECEIVE DATA
// ==========================================
socket.on('merel_response', (data) => {
    addMessage('Merel', data.text, 'merel');

    if (data.brain_activity) {
        currentActivations = data.brain_activity;
        spawnParticles();
    }
});

function spawnParticles() {
    for (let i = 0; i < currentActivations.length; i++) {
        const val = currentActivations[i];
        if (Math.abs(val) > 0.3) { // Lower threshold for more activity
            particles.push({
                index: i,
                progress: 0,
                speed: 0.01 + Math.random() * 0.02,
                angleOffset: Math.random() * Math.PI * 2,
                color: val > 0 ? 0xd4a24c : 0xa83a3a
            });
        }
    }
}

// ==========================================
// VISUAL ANIMATION
// ==========================================
app.ticker.add((delta) => {
    // Clear the main graphics, but NOT the trail (we fade the trail)
    connectionGraphics.clear();
    neuronGraphics.clear();
    particleGraphics.clear();

    // 1. Fade the trail layer
    trailGraphics.alpha -= 0.05;
    if (trailGraphics.alpha <= 0) {
        trailGraphics.clear();
        trailGraphics.alpha = 1;
    }

    const width = app.screen.width;
    const height = app.screen.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.35; // Bigger radius

    const time = performance.now() / 1000;
    const numNeurons = currentActivations.length;

    // 2. Draw Central Core with a "breathing" effect
    const totalActivity = currentActivations.reduce((a, b) => a + Math.abs(b), 0);
    const coreRadius = 15 + (totalActivity * 3) + Math.sin(time * 3) * 5;

    // Core glow
    for (let i = 3; i > 0; i--) {
        neuronGraphics.beginFill(0xd4a24c, 0.1 / i);
        neuronGraphics.drawCircle(centerX, centerY, coreRadius * (1 + i * 0.5));
        neuronGraphics.endFill();
    }
    neuronGraphics.beginFill(0xffdd88, 0.8);
    neuronGraphics.drawCircle(centerX, centerY, coreRadius * 0.5);
    neuronGraphics.endFill();

    // 3. Draw Neurons and Connections
    for (let i = 0; i < numNeurons; i++) {
        const angle = (i / numNeurons) * Math.PI * 2;
        const val = currentActivations[i];

        // Distance from center based on activation (breathes)
        const dist = radius + (val * 40) + Math.sin(time * 2 + i) * 10;
        const x = centerX + Math.cos(angle) * dist;
        const y = centerY + Math.sin(angle) * dist;

        // Draw the connection line
        const lineAlpha = Math.min(Math.abs(val) * 1.5, 0.8);
        if (lineAlpha > 0.05) {
            connectionGraphics.lineStyle(1.5, 0xd4a24c, lineAlpha);
            connectionGraphics.moveTo(centerX, centerY);
            connectionGraphics.lineTo(x, y);

            // Add to trail
            trailGraphics.lineStyle(1, 0xd4a24c, lineAlpha * 0.5);
            trailGraphics.moveTo(centerX, centerY);
            trailGraphics.lineTo(x, y);
        }

        // Draw the neuron dot
        const dotColor = val > 0 ? 0xd4a24c : 0xa83a3a;
        const dotSize = 3 + Math.abs(val) * 4; // Nodes pulse in size

        neuronGraphics.beginFill(dotColor, Math.min(Math.abs(val) * 2, 1));
        neuronGraphics.drawCircle(x, y, dotSize);
        neuronGraphics.endFill();
    }

    // 4. Draw and Update Particles (Orbiting inwards)
    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.progress += p.speed;

        const angle = (p.index / numNeurons) * Math.PI * 2;

        // The particle spirals inward
        const currentRadius = radius * (1 - p.progress);
        const currentAngle = angle + (p.progress * Math.PI * 2); // Spiral effect

        const currentX = centerX + Math.cos(currentAngle) * currentRadius;
        const currentY = centerY + Math.sin(currentAngle) * currentRadius;

        const alpha = 1 - p.progress;

        // Particle
        particleGraphics.beginFill(p.color, alpha);
        particleGraphics.drawCircle(currentX, currentY, 2 + (1 - p.progress) * 2);
        particleGraphics.endFill();

        // Particle Trail
        trailGraphics.beginFill(p.color, alpha * 0.3);
        trailGraphics.drawCircle(currentX, currentY, 3);
        trailGraphics.endFill();

        if (p.progress >= 1) {
            particles.splice(i, 1);
        }
    }
});
