// ==========================================
// 1. 2D NEURON (WITH PHYSICS)
// ==========================================
class Neuron2D {
    constructor(index, total, centerX, centerY, radius) {
        this.index = index;
        this.activation = 0;
        this.targetActivation = 0;

        // Start in a circle
        const angle = (index / total) * Math.PI * 2;
        this.x = centerX + Math.cos(angle) * radius;
        this.y = centerY + Math.sin(angle) * radius;

        // Physics
        this.vx = (Math.random() - 0.5) * 2;
        this.vy = (Math.random() - 0.5) * 2;
        this.centerX = centerX;
        this.centerY = centerY;
    }

    update(time) {
        this.activation += (this.targetActivation - this.activation) * 0.1;

        // Attraction to center
        const dx = this.centerX - this.x;
        const dy = this.centerY - this.y;
        const dist = Math.sqrt(dx*dx + dy*dy) || 1;

        // Active nodes pull harder
        const force = 0.01 + (Math.abs(this.activation) * 0.05);
        this.vx += (dx / dist) * force;
        this.vy += (dy / dist) * force;

        // Apply velocity
        this.x += this.vx;
        this.y += this.vy;

        // Friction
        this.vx *= 0.95;
        this.vy *= 0.95;
    }
}

// ==========================================
// 2. BRAIN VISUALIZER (FORCE-DIRECTED)
// ==========================================
class BrainVisualizer2D {
    constructor() {
        this.app = new PIXI.Application({
            backgroundColor: 0x050505,
            antialias: true,
            resolution: window.devicePixelRatio || 1,
            width: window.innerWidth,
            height: window.innerHeight
        });
        document.getElementById('brain-container').appendChild(this.app.view);

        this.container = new PIXI.Container();
        this.container.blendMode = PIXI.BLEND_MODES.ADD;
        this.app.stage.addChild(this.container);

        this.graphics = new PIXI.Graphics();
        this.container.addChild(this.graphics);

        this.neurons = [];
        this.numNeurons = 256;
        this.timeOffset = 0;

        this.initNeurons();
        this.app.ticker.add(this.animate.bind(this));
    }

    initNeurons() {
        const width = this.app.renderer.width / this.app.renderer.resolution;
        const height = this.app.renderer.height / this.app.renderer.resolution;
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) * 0.35;

        this.neurons = [];
        for (let i = 0; i < this.numNeurons; i++) {
            this.neurons.push(new Neuron2D(i, this.numNeurons, centerX, centerY, radius));
        }
    }

    updateActivations(activations) {
        for (let i = 0; i < this.neurons.length; i++) {
            if (i < activations.length) {
                this.neurons[i].targetActivation = activations[i];
            }
        }
        this.timeOffset += 2;
    }

    animate(delta) {
        const time = performance.now() / 1000 + this.timeOffset;
        this.graphics.clear();

        const width = this.app.renderer.width / this.app.renderer.resolution;
        const height = this.app.renderer.height / this.app.renderer.resolution;
        const centerX = width / 2;
        const centerY = height / 2;

        // Update positions
        this.neurons.forEach(n => n.update(time));

        // Apply Repulsion
        for (let i = 0; i < this.neurons.length; i++) {
            const n1 = this.neurons[i];
            for (let j = i + 1; j < this.neurons.length; j++) {
                const n2 = this.neurons[j];
                const dx = n2.x - n1.x;
                const dy = n2.y - n1.y;
                const distSq = dx*dx + dy*dy;
                const dist = Math.sqrt(distSq) || 1;

                if (dist < 50) {
                    const push = (50 - dist) / 50;
                    n1.vx -= (dx / dist) * push * 0.5;
                    n1.vy -= (dy / dist) * push * 0.5;
                    n2.vx += (dx / dist) * push * 0.5;
                    n2.vy += (dy / dist) * push * 0.5;
                }
            }
        }

        // 1. Draw Connections (Synaptic Web)
        for (let i = 0; i < this.neurons.length; i++) {
            const n1 = this.neurons[i];
            for (let j = i + 1; j < this.neurons.length; j++) {
                const n2 = this.neurons[j];
                const dx = n1.x - n2.x;
                const dy = n1.y - n2.y;
                const dist = Math.sqrt(dx*dx + dy*dy);

                if (dist < 80) {
                    const alpha = (1 - dist / 80) * (Math.abs(n1.activation) + Math.abs(n2.activation)) * 0.5;
                    if (alpha > 0.05) {
                        const color = (n1.activation > 0 && n2.activation > 0) ? 0x00ffff : 0xff00aa;
                        this.graphics.lineStyle(1, color, alpha);
                        this.graphics.moveTo(n1.x, n1.y);
                        this.graphics.lineTo(n2.x, n2.y);
                    }
                }
            }
        }

        // --- REMOVED THE CENTRAL CORE ---
        // The core is now gone. The center is pure dark space.

        // 2. Draw Nodes
        this.neurons.forEach(n => {
            const color = n.activation > 0 ? 0x00ffff : 0xff00aa;
            const alpha = Math.min(Math.abs(n.activation) * 2 + 0.2, 1);
            const size = 2 + Math.abs(n.activation) * 3;

            this.graphics.beginFill(color, alpha * 0.3);
            this.graphics.drawCircle(n.x, n.y, size * 2);
            this.graphics.beginFill(color, alpha);
            this.graphics.drawCircle(n.x, n.y, size);
            this.graphics.endFill();
        });
    }
}

// ==========================================
// 3. CHAT CONTROLLER
// ==========================================
class ChatController {
    constructor(brain) {
        this.brain = brain;
        this.socket = io();
        this.chatHistory = document.getElementById('chat-history');
        this.userInput = document.getElementById('user-input');

        this.setupSocket();
        this.setupInput();
    }

    setupSocket() {
        this.socket.on('merel_response', (data) => {
            this.addMessage('Merel', data.text, 'merel');

            if (data.brain_activity) {
                this.brain.updateActivations(data.brain_activity);
            }

            if (data.data_source) document.getElementById('data-source').textContent = data.data_source;
            if (data.top_nodes) document.getElementById('top-nodes').textContent = data.top_nodes.join(', ');
        });
    }

    setupInput() {
        this.userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && this.userInput.value.trim() !== '') {
                const text = this.userInput.value;
                this.userInput.value = '';

                this.addMessage('You', text, 'user');
                this.socket.emit('user_message', { text: text });

                this.brain.timeOffset += 2;
            }
        });
    }

    addMessage(sender, text, className) {
        const div = document.createElement('div');
        div.className = `msg ${className}`;
        div.innerHTML = `<strong>${sender}:</strong> ${text}`;
        this.chatHistory.appendChild(div);
        this.chatHistory.scrollTop = this.chatHistory.scrollHeight;
    }
}

// ==========================================
// 4. BOOTSTRAP
// ==========================================
window.addEventListener('load', () => {
    const brain = new BrainVisualizer2D();
    const chat = new ChatController(brain);

    window.addEventListener('resize', () => {
        const container = document.getElementById('brain-container');
        if (container) {
            brain.app.renderer.resize(container.clientWidth, container.clientHeight);
            brain.initNeurons(); // Recalculate positions
        }
    });
});
