const socket = io();
const chatHistory = document.getElementById('chat-history');
const userInput = document.getElementById('user-input');

// ==========================================
// PIXIJS SETUP (LIGHTWEIGHT)
// ==========================================
const app = new PIXI.Application({
    backgroundColor: 0x050505,
    antialias: true,
    resolution: window.devicePixelRatio || 1,
    width: window.innerWidth,  // Start with full window size
    height: window.innerHeight
});
document.getElementById('brain-container').appendChild(app.view);

// We only need ONE graphics layer now for maximum performance
const graphics = new PIXI.Graphics();
app.stage.addChild(graphics);

let currentActivations = new Array(128).fill(0);
let targetActivations = new Array(128).fill(0);

let rotX = 0;
let rotY = 0;
let targetRotX = 0;
let targetRotY = 0;

// Real resize logic
window.addEventListener('resize', () => {
    const container = document.getElementById('brain-container');
    if (container) {
        app.renderer.resize(container.clientWidth, container.clientHeight);
    }
});

// One-time setup after a small delay to let CSS load
setTimeout(() => {
    const container = document.getElementById('brain-container');
    if (container) {
        app.renderer.resize(container.clientWidth, container.clientHeight);
    }
}, 200);

// ==========================================
// CHAT LOGIC
// ==========================================
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && userInput.value.trim() !== '') {
        const text = userInput.value;
        userInput.value = '';

        addMessage('You', text, 'user');
        socket.emit('user_message', { text: text });

        targetRotX += (Math.random() - 0.5) * 1.5;
        targetRotY += (Math.random() - 0.5) * 1.5;
    }
});

function addMessage(sender, text, className) {
    const div = document.createElement('div');
    div.className = `msg ${className}`;
    div.innerHTML = `<strong>${sender}:</strong> ${text}`;
    chatHistory.appendChild(div);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// ==========================================
// RECEIVE DATA
// ==========================================
socket.on('merel_response', (data) => {
    addMessage('Merel', data.text, 'merel');
    if (data.brain_activity) {
        targetActivations = data.brain_activity;
        targetRotX += (Math.random() - 0.5) * 2;
        targetRotY += (Math.random() - 0.5) * 2;
    }
});

// ==========================================
// 3D MATH
// ==========================================
function rotate3D(x, y, z, angleX, angleY) {
    let cosY = Math.cos(angleY);
    let sinY = Math.sin(angleY);
    let x1 = x * cosY - z * sinY;
    let z1 = x * sinY + z * cosY;

    let cosX = Math.cos(angleX);
    let sinX = Math.sin(angleX);
    let y1 = y * cosX - z1 * sinX;
    let z2 = y * sinX + z1 * cosX;

    return { x: x1, y: y1, z: z2 };
}

// ==========================================
// ANIMATION LOOP
// ==========================================

app.ticker.add((delta) => {
    const dt = delta / 60;

    for (let i = 0; i < currentActivations.length; i++) {
        currentActivations[i] += (targetActivations[i] - currentActivations[i]) * 0.1;
    }

    rotX += (targetRotX - rotX) * 0.05;
    rotY += (targetRotY - rotY) * 0.05;
    targetRotY += 0.003; // Slow idle rotation

    graphics.clear();

    // Force the dimensions to match the actual DOM container
    const container = document.getElementById('brain-container');
    // Force the dimensions to match the actual canvas
    const width = app.renderer.width / app.renderer.resolution;
    const height = app.renderer.height / app.renderer.resolution;
    const centerX = width / 2;
    const centerY = height / 2;
    const baseRadius = Math.min(width, height) * 0.3; // Slightly smaller
    const numNeurons = currentActivations.length;
    const time = performance.now() / 1000;

    // 1. Calculate 3D points
    let points = [];
    for (let i = 0; i < numNeurons; i++) {
        const phi = Math.acos(1 - 2 * (i + 0.5) / numNeurons);
        const theta = Math.PI * (1 + Math.sqrt(5)) * i;
        const val = currentActivations[i];
        const r = baseRadius + (val * 30); // Less deformation for cleaner look

        let x = r * Math.sin(phi) * Math.cos(theta);
        let y = r * Math.sin(phi) * Math.sin(theta);
        let z = r * Math.cos(phi);

        const rotated = rotate3D(x, y, z, rotX, rotY);

        // Project to 2D
        const fov = 800;
        const scale = fov / (fov + rotated.z);

        points.push({
            x: centerX + rotated.x * scale,
            y: centerY + rotated.y * scale,
            z: rotated.z,
            scale: scale,
            val: val
        });
    }

    // Sort for depth
    points.sort((a, b) => b.z - a.z);

    // 2. Draw Wireframe (Only draw lines between close points)
    for (let i = 0; i < numNeurons; i++) {
        const p1 = points[i];

        // Draw connections to nearby nodes
        for (let j = i + 1; j < numNeurons; j++) {
            const p2 = points[j];
            const dx = p1.x - p2.x;
            const dy = p1.y - p2.y;
            const dist = Math.sqrt(dx*dx + dy*dy);

            // Only connect if they are close (creates a mesh)
            if (dist < 60) {
                // Brighter lines for active nodes
                const activity = (Math.abs(p1.val) + Math.abs(p2.val)) / 2;
                const alpha = (1 - dist / 60) * (0.1 + activity);

                graphics.lineStyle(1, 0x00ffff, Math.min(alpha, 0.6));
                graphics.moveTo(p1.x, p1.y);
                graphics.lineTo(p2.x, p2.y);
            }
        }
    }

    // 3. Draw Nodes (Simple circles, no glow)
    for (let i = 0; i < numNeurons; i++) {
        const p = points[i];
        const color = p.val > 0 ? 0x00ffff : 0xff00aa;
        const alpha = Math.min(Math.abs(p.val) * 2 + 0.3, 1) * p.scale;
        const size = (1.5 + Math.abs(p.val) * 2.5) * p.scale;

        graphics.beginFill(color, alpha);
        graphics.drawCircle(p.x, p.y, size);
        graphics.endFill();
    }

    // 4. Draw Central Core (Simple ring)
    const totalActivity = currentActivations.reduce((a, b) => a + Math.abs(b), 0);
    const coreRadius = 30 + (totalActivity * 1.5) + Math.sin(time * 2) * 3;

    graphics.lineStyle(1.5, 0x00ffff, 0.8);
    graphics.drawCircle(centerX, centerY, coreRadius);

    graphics.beginFill(0x00ffff, 0.1);
    graphics.drawCircle(centerX, centerY, coreRadius * 0.8);
    graphics.endFill();
});
// Force the canvas to be the exact size of the container
function resizeCanvas() {
    const container = document.getElementById('brain-container');
    app.renderer.resize(container.clientWidth, container.clientHeight);
}

// Resize once on load
window.addEventListener('load', () => {
    setTimeout(resizeCanvas, 100);
});

// Resize whenever the window changes
window.addEventListener('resize', resizeCanvas);
