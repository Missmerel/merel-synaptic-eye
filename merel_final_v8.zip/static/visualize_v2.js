// ==========================================
// 1. 2D NEURON (WITH DECAY)
// ==========================================
class Neuron2D {
    constructor(index, total, centerX, centerY, radius) {
        this.index = index;
        this.activation = 0;
        this.targetActivation = 0;
        this.decay = 0;

        const angle = (index / total) * Math.PI * 2;
        this.x = centerX + Math.cos(angle) * radius;
        this.y = centerY + Math.sin(angle) * radius;

        this.vx = (Math.random() - 0.5) * 2;
        this.vy = (Math.random() - 0.5) * 2;
        this.centerX = centerX;
        this.centerY = centerY;
    }

    update(time) {
        this.activation += (this.targetActivation - this.activation) * 0.1;

        if (Math.abs(this.targetActivation) > 0.5 && this.decay < 0.1) {
            this.decay = 1.0;
        } else {
            this.decay = Math.max(0, this.decay - 0.03);
        }

        const dx = this.centerX - this.x;
        const dy = this.centerY - this.y;
        const dist = Math.sqrt(dx*dx + dy*dy) || 1;

        const force = Math.min(0.01 + (Math.abs(this.activation) * 0.1) + (this.decay * 0.05), 0.5);
        this.vx += (dx / dist) * force;
        this.vy += (dy / dist) * force;

        this.vx *= 0.95;
        this.vy *= 0.95;
        this.x += this.vx;
        this.y += this.vy;
    }
}

// ==========================================
// 2. BRAIN VISUALIZER
// ==========================================
class BrainVisualizer2D {
    constructor() {
        this.app = new PIXI.Application({
            backgroundColor: 0x050505,
            antialias: true,
            resolution: window.devicePixelRatio || 1,
            resizeTo: document.getElementById('brain-container'),
            autoDensity: true
        });
        document.getElementById('brain-container').appendChild(this.app.view);

        this.container = new PIXI.Container();
        this.container.blendMode = PIXI.BLEND_MODES.ADD;
        this.app.stage.addChild(this.container);

        this.graphics = new PIXI.Graphics();
        this.container.addChild(this.graphics);

        this.neurons = [];
        this.numNeurons = 256;
        this.timeOffset = 0;
        this.pulseWaves = [];

        this.container.eventMode = 'static';
        this.container.hitArea = new PIXI.Rectangle(0, 0, window.innerWidth, window.innerHeight);
        this.container.cursor = 'grab';

        this.isDragging = false;
        this.dragStart = { x: 0, y: 0 };
        this.containerStart = { x: 0, y: 0 };

        this.container.on('pointerdown', (e) => {
            this.isDragging = true;
            this.container.cursor = 'grabbing';
            this.dragStart.x = e.data.global.x;
            this.dragStart.y = e.data.global.y;
            this.containerStart.x = this.container.x;
            this.containerStart.y = this.container.y;
        });

        this.container.on('pointermove', (e) => {
            if (this.isDragging) {
                const dx = e.data.global.x - this.dragStart.x;
                const dy = e.data.global.y - this.dragStart.y;
                this.container.x = this.containerStart.x + dx;
                this.container.y = this.containerStart.y + dy;
            }
        });

        this.container.on('pointerup', () => { this.isDragging = false; this.container.cursor = 'grab'; });
        this.container.on('pointerupoutside', () => { this.isDragging = false; this.container.cursor = 'grab'; });

        this.app.view.addEventListener('wheel', (e) => {
            e.preventDefault();
            const scale = this.container.scale.x;
            const newScale = scale + (e.deltaY > 0 ? -0.1 : 0.1);
            if (newScale > 0.2 && newScale < 5) { this.container.scale.set(newScale); }
        });

        this.app.ticker.add(this.animate.bind(this));
        this.app.renderer.on('resize', () => { this.initNeurons(); });
        this.initNeurons();
    }

    initNeurons() {
        const width = this.app.screen.width;
        const height = this.app.screen.height;
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) * 0.35;

        this.neurons = [];
        for (let i = 0; i < this.numNeurons; i++) {
            this.neurons.push(new Neuron2D(i, this.numNeurons, centerX, centerY, radius));
        }
    }

    updateActivations(activations) {
        if (!activations) return;
        this.pulseWaves = [];

        for (let i = 0; i < this.neurons.length; i++) {
            if (i < activations.length) {
                const val = Number(activations[i]);
                this.neurons[i].targetActivation = isNaN(val) ? 0 : val;
            }
        }
        this.timeOffset += 2;
        this.pulseWaves.push({ radius: 0, alpha: 0.5, speed: 2 });
    }

    animate(delta) {
        try {
            const time = performance.now() / 1000 + this.timeOffset;
            this.graphics.clear();

            const width = this.app.screen.width;
            const height = this.app.screen.height;
            const centerX = width / 2;
            const centerY = height / 2;

            this.neurons.forEach(n => n.update(time));

            for (let i = 0; i < this.neurons.length; i++) {
                const n1 = this.neurons[i];
                for (let j = i + 1; j < this.neurons.length; j++) {
                    const n2 = this.neurons[j];
                    const dx = n2.x - n1.x; const dy = n2.y - n1.y;
                    const dist = Math.sqrt(dx*dx + dy*dy) || 1;
                    if (dist < 50) {
                        const push = (50 - dist) / 50;
                        n1.vx -= (dx / dist) * push * 0.5; n1.vy -= (dy / dist) * push * 0.5;
                        n2.vx += (dx / dist) * push * 0.5; n2.vy += (dy / dist) * push * 0.5;
                    }
                }
            }

            if (this.pulseWaves && this.pulseWaves.length > 0) {
                for (let i = this.pulseWaves.length - 1; i >= 0; i--) {
                    const wave = this.pulseWaves[i];
                    if (!wave || isNaN(wave.radius) || isNaN(wave.alpha)) {
                        this.pulseWaves.splice(i, 1);
                        continue;
                    }
                    wave.radius += wave.speed;
                    wave.alpha -= 0.01;
                    if (wave.alpha > 0) {
                        this.graphics.lineStyle(2, 0x00ffff, wave.alpha);
                        this.graphics.drawCircle(centerX, centerY, wave.radius);
                    } else {
                        this.pulseWaves.splice(i, 1);
                    }
                }
            }

            for (let i = 0; i < this.neurons.length; i++) {
                const n1 = this.neurons[i];
                for (let j = i + 1; j < this.neurons.length; j++) {
                    const n2 = this.neurons[j];
                    const dx = n1.x - n2.x; const dy = n1.y - n2.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    if (dist < 80) {
                        const avg = (Math.abs(n1.activation) + Math.abs(n2.activation)) * 0.5;
                        const alpha = (1 - dist / 80) * avg;
                        if (alpha > 0.05) {
                            const color = (n1.activation > 0 && n2.activation > 0) ? 0x00ffff : 0xff00aa;
                            this.graphics.lineStyle(1, color, alpha);
                            this.graphics.moveTo(n1.x, n1.y);
                            this.graphics.lineTo(n2.x, n2.y);
                        }
                    }
                }
            }

            this.neurons.forEach(n => {
                if (isNaN(n.x) || isNaN(n.y)) return;
                const baseColor = n.activation > 0 ? 0x00ffff : 0xff00aa;
                const color = n.decay > 0.8 ? 0xffffff : baseColor;
                const intensity = Math.max(Math.abs(n.activation), n.decay);
                const alpha = Math.min(intensity * 2 + 0.1, 1);
                const size = 2 + intensity * 4;

                this.graphics.beginFill(color, alpha * 0.2);
                this.graphics.drawCircle(n.x, n.y, size * 3);
                this.graphics.beginFill(color, alpha);
                this.graphics.drawCircle(n.x, n.y, size);
                this.graphics.endFill();
            });

        } catch (e) {
            console.error("Animate crash:", e);
        }
    }
}

// ==========================================
// 3. CHAT CONTROLLER
// ==========================================
class ChatController {
    constructor(brain) {
        this.brain = brain;
        this.socket = io();
        this.chatHistory = document.getElementById('chat-history');
        this.userInput = document.getElementById('user-input');

        this.setupSocket();
        this.setupInput();
    }

    setupSocket() {
        this.socket.on('merel_response', (data) => {
            this.addMessage('Merel', data.text, 'merel');

            if (data.brain_activity) {
                this.brain.updateActivations(data.brain_activity);

                const streamEl = document.getElementById('data-stream');
                if (streamEl) {
                    const displayData = data.brain_activity;
                    const barsHTML = displayData.map((val, index) => {
                        const safeVal = isNaN(val) ? 0 : val;
                        const heightPercent = Math.min(Math.abs(safeVal) * 30, 100);
                        let className = 'neutral';
                        if (safeVal > 0.1) className = 'positive';
                        else if (safeVal < -0.1) className = 'negative';
                        const waveDelay = (index * 0.02) % 1;
                        return `<div style="flex-grow: 1; display: flex; align-items: flex-end; height: 100%;">
                                    <div class="bar ${className}" style="height: ${heightPercent}%; width: 100%; animation-delay: ${waveDelay}s;"></div>
                                </div>`;
                    }).join('');
                    streamEl.innerHTML = barsHTML;
                }
            }

            if (data.data_source) document.getElementById('data-source').textContent = data.data_source;
            if (data.top_nodes) document.getElementById('top-nodes').textContent = data.top_nodes.join(', ');
        });
    }

    setupInput() {
        this.userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && this.userInput.value.trim() !== '') {
                const text = this.userInput.value;
                this.userInput.value = '';
                this.addMessage('You', text, 'user');
                this.socket.emit('user_message', { text: text });
                this.brain.timeOffset += 2;
            }
        });
    }

    addMessage(sender, text, className) {
        const div = document.createElement('div');
        div.className = `msg ${className}`;
        div.innerHTML = `<strong>${sender}:</strong> ${text}`;
        this.chatHistory.appendChild(div);
        this.chatHistory.scrollTop = this.chatHistory.scrollHeight;
    }
}

// ==========================================
// 4. BOOTSTRAP
// ==========================================
window.addEventListener('load', () => {
    const brain = new BrainVisualizer2D();
    const chat = new ChatController(brain);

    // Force resize after CSS has fully loaded
    setTimeout(() => {
        const container = document.getElementById('brain-container');
        if (container) {
            const width = container.clientWidth;
            const height = container.clientHeight;

            // Force the PixiJS renderer to match the exact DOM size
            brain.app.renderer.resize(width, height);

            // Re-initialize neurons with the correct center point
            brain.initNeurons();

            console.log(`Brain resized to ${width}x${height}`);
        }
    }, 500); // Increased to 500ms to give CSS time to load
});
