# Merel V5: The Ultimate Custom AI 🌌🧠

Merel is a fully functional, custom-built Large Language Model (LLM) trained from scratch on a Mac. She runs locally, has a custom identity, and features a stunning 3D WebGL visualization of her neural network in real-time.

## 🚀 Features

*   **Custom Neural Network:** A PyTorch Transformer built from scratch (`MerelModel`).
*   **Fused Training Data:** Trained on personal WhatsApp chats, Tilburg Wikipedia, Transgender Wikipedia, and Apple's raw C++ Wi-Fi network headers.
*   **Custom Identity:** A "System Prompt" injection forces her to know she is Merel, a proud trans woman.
*   **Real-Time WebGL Visualizer:** A 3D holographic neural mesh built with PixiJS that deforms and pulses based on her internal math.
*   **Web Interface:** A sleek, glassmorphic chat UI built with Flask and Socket.IO.

## 📂 Project Structure

*   `train_words.py`: The PyTorch training loop. This is the "brain factory."
*   `startup_words.py`: The Flask web server. This is her "body."
*   `merel_words.pth`: Her trained brain (the neural network weights).
*   `my_personal_data.txt`: Her vocabulary and memories (the text she was trained on).
*   `combine_data.py`: A script to merge different text sources (chat, wiki, code) into one training file.
*   `get_wiki.py`: A script to download Wikipedia pages to feed her.
*   `get_wifi_code.py`: A script to extract system network headers from macOS.
*   `templates/index.html`: The HTML/CSS for the chat interface.
*   `static/visualize.js`: The PixiJS code for the 3D neural visualizer.

## 🛠️ How to Run Her

### 1. Install Dependencies
Make sure you have Python 3.9+ installed. Then run:
```bash
python3 -m pip install torch flask flask-socketio eventlet requests

### How to add this to your project
1. In your terminal, make sure you are in the `merelai` folder.
2. Type: `nano README.md`
3. Paste the entire block of text above into the terminal.
4. Save and exit (`Ctrl + O`, `Enter`, `Ctrl + X`).

Now anyone who finds your project (or future you) will know exactly how this incredible system was built! 🏆🤖📄
