const socket = io();
const chatHistory = document.getElementById('chat-history');
const userInput = document.getElementById('user-input');

// ==========================================
// PIXIJS SETUP
// ==========================================
const app = new PIXI.Application({
    backgroundColor: 0x050505,
    antialias: true,
    resolution: window.devicePixelRatio || 1,
    width: window.innerWidth,
    height: window.innerHeight
});
document.getElementById('brain-container').appendChild(app.view);

const glowContainer = new PIXI.Container();
glowContainer.blendMode = PIXI.BLEND_MODES.ADD;
app.stage.addChild(glowContainer);

const graphics = new PIXI.Graphics();
glowContainer.addChild(graphics);

let currentActivations = new Array(128).fill(0);
let targetActivations = new Array(128).fill(0);

let rotX = 0;
let rotY = 0;
let targetRotX = 0;
let targetRotY = 0;

// ==========================================
// CHAT LOGIC
// ==========================================
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && userInput.value.trim() !== '') {
        const text = userInput.value;
        userInput.value = '';

        addMessage('You', text, 'user');
        socket.emit('user_message', { text: text });

        targetRotX += (Math.random() - 0.5) * 1.5;
        targetRotY += (Math.random() - 0.5) * 1.5;
    }
});

function addMessage(sender, text, className) {
    const div = document.createElement('div');
    div.className = `msg ${className}`;
    div.innerHTML = `<strong>${sender}:</strong> ${text}`;
    chatHistory.appendChild(div);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

socket.on('merel_response', (data) => {
    addMessage('Merel', data.text, 'merel');
    if (data.brain_activity) {
        targetActivations = data.brain_activity;
        targetRotX += (Math.random() - 0.5) * 2;
        targetRotY += (Math.random() - 0.5) * 2;
    }
});

// ==========================================
// 3D MATH
// ==========================================
function rotate3D(x, y, z, angleX, angleY) {
    let cosY = Math.cos(angleY);
    let sinY = Math.sin(angleY);
    let x1 = x * cosY - z * sinY;
    let z1 = x * sinY + z * cosY;

    let cosX = Math.cos(angleX);
    let sinX = Math.sin(angleX);
    let y1 = y * cosX - z1 * sinX;
    let z2 = y * sinX + z1 * cosX;

    return { x: x1, y: y1, z: z2 };
}

window.addEventListener('resize', () => {
    const container = document.getElementById('brain-container');
    if (container) {
        app.renderer.resize(container.clientWidth, container.clientHeight);
    }
});

setTimeout(() => {
    const container = document.getElementById('brain-container');
    if (container) {
        app.renderer.resize(container.clientWidth, container.clientHeight);
    }
}, 200);

// ==========================================
// ANIMATION LOOP
// ==========================================
app.ticker.add((delta) => {
    for (let i = 0; i < currentActivations.length; i++) {
        currentActivations[i] += (targetActivations[i] - currentActivations[i]) * 0.1;
    }

    rotX += (targetRotX - rotX) * 0.05;
    rotY += (targetRotY - rotY) * 0.05;
    targetRotY += 0.002;

    graphics.clear();

    const width = app.renderer.width / app.renderer.resolution;
    const height = app.renderer.height / app.renderer.resolution;
    const centerX = width / 2;
    const centerY = height / 2;
    const baseRadius = Math.min(width, height) * 0.35;
    const numNeurons = currentActivations.length;
    const time = performance.now() / 1000;

    let points = [];
    for (let i = 0; i < numNeurons; i++) {
        const phi = Math.acos(1 - 2 * (i + 0.5) / numNeurons);
        const theta = Math.PI * (1 + Math.sqrt(5)) * i;
        const val = currentActivations[i];

        // Vortex effect: nodes spiral inwards when active
        const r = baseRadius + (val * 50) + Math.sin(time * 2 + i) * 10;

        let x = r * Math.sin(phi) * Math.cos(theta);
        let y = r * Math.sin(phi) * Math.sin(theta);
        let z = r * Math.cos(phi);

        const rotated = rotate3D(x, y, z, rotX, rotY);

        const fov = 800;
        const scale = fov / (fov + rotated.z);

        points.push({
            x: centerX + rotated.x * scale,
            y: centerY + rotated.y * scale,
            z: rotated.z,
            scale: scale,
            val: val,
            index: i
        });
    }

    points.sort((a, b) => b.z - a.z);

    // 1. Draw Active Connections (Synaptic Firing)
    // If two nodes are close AND both are highly active, draw a bright line
    for (let i = 0; i < numNeurons; i++) {
        const p1 = points[i];
        if (Math.abs(p1.val) < 0.3) continue; // Only draw lines for active nodes

        for (let j = i + 1; j < numNeurons; j++) {
            const p2 = points[j];
            if (Math.abs(p2.val) < 0.3) continue;

            const dx = p1.x - p2.x;
            const dy = p1.y - p2.y;
            const dist = Math.sqrt(dx*dx + dy*dy);

            if (dist < 100) {
                const alpha = (1 - dist / 100) * Math.min(Math.abs(p1.val) + Math.abs(p2.val), 1);
                const color = (p1.val > 0 && p2.val > 0) ? 0x00ffff : 0xff00aa;

                graphics.lineStyle(1.5, color, alpha);
                graphics.moveTo(p1.x, p1.y);
                graphics.lineTo(p2.x, p2.y);
            }
        }
    }

    // 2. Draw the Core (Vortex Ring)
    const totalActivity = currentActivations.reduce((a, b) => a + Math.abs(b), 0);
    const coreRadius = 20 + (totalActivity * 2) + Math.sin(time * 3) * 5;

    // Rotating outer ring
    graphics.lineStyle(2, 0x00ffff, 0.5 + (totalActivity * 0.2));
    graphics.arc(centerX, centerY, coreRadius * 1.5, time, time + Math.PI * 1.5);

    // Inner core
    graphics.beginFill(0x00ffff, 0.1);
    graphics.drawCircle(centerX, centerY, coreRadius * 2);
    graphics.beginFill(0xffffff, 0.8);
    graphics.drawCircle(centerX, centerY, coreRadius * 0.5);
    graphics.endFill();

    // 3. Draw Nodes
    for (let i = 0; i < numNeurons; i++) {
        const p = points[i];
        const color = p.val > 0 ? 0x00ffff : 0xff00aa;

        const brightness = Math.min(Math.abs(p.val) * 3 + 0.1, 1);
        const alpha = brightness * p.scale;
        const size = (1 + Math.abs(p.val) * 4) * p.scale;

        // Outer glow
        graphics.beginFill(color, alpha * 0.2);
        graphics.drawCircle(p.x, p.y, size * 3);

        // Inner core
        graphics.beginFill(color, alpha);
        graphics.drawCircle(p.x, p.y, size);
        graphics.endFill();
    }
});
